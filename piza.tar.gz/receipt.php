<!DOCTYPE html>
<html>
<head>
	<title>Receipt</title>
</head>
<body>




<?php 
require('mysqli_connect.php');

$SQLString = "SELECT * FROM orders ORDER BY id";
$result = mysqli_query($dbc, $SQLString);


if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["email"]. "<br>";
    }
} else {
    echo "0 results";
}

?>


</body>
</html>