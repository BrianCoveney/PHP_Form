<?php 


    require_once('mysqli_connect.php');
    include('vieworder.php');

    $SQLString = "SELECT * FROM orders";
    $result = mysqli_query($dbc, $SQLString);


    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $rFirstName = $row["firstname"];
            $rEmail = $row['email'];
            $rAddress = $row['address'];
            $rPhoneNo = $row['phone'];
        }
    } else {
        echo "0 results";
    }

?>
<h2 id="heading">Pizzas Order Form</h2>
    <form action="receipt.php"  method="post" novalidate>
        <input type="hidden" id="small" type="radio" name="pizzaSize" value="small" onChange="redraw()"/>
        <input type="hidden" id="medium" type="radio" name="pizzaSize" value="medium" onChange="redraw()" />
        <input type="hidden" id="large" type="radio" name="pizzaSize" value="large" onChange="redraw()" checked/> 
        <input type="hidden" id="anchovies" type="checkbox" name="addAnchovies" value="yes" onChange="redraw()" checked/>
        <input type="hidden" id="pineapple" type="checkbox" name="addPineapple" value="yes" onChange="redraw()" checked/>     
        <input type="hidden" id="pepperoni" type="checkbox" name="addPepperoni" value="yes" onChange="redraw()" checked/>
        <input type="hidden" id="olives" type="checkbox" name="addOlives" value="yes" onChange="redraw()" checked/>
        <input type="hidden" id="onion" type="checkbox" name="addOnion" value="yes" onChange="redraw()" checked/>
        <input type="hidden" id="peppers" type="checkbox" name="addPeppers" value="yes" onChange="redraw()" checked/>


        <h3>Enter your  details</h3>
        First Name:
        <input name="firstname" id="cname" type="text" value='<?php echo $rFirstName; ?>'/><span class="error"><?php echo $nameError;?></span>
        <br/>
        <br/>
        Address:
        <textarea name="address" id = "caddress" type="text"rows="5" cols="30"/><?php echo $rAddress;?></textarea>
        <span class="error"><?php echo $addressError;?></span>
        <br/>
        <br/>
        Email Address:
        <input name="email" type="email" value="<?php echo $rEmail; ?>"/><span class="error"><?php echo $emailError; ?></span>
        <br/>
        <br/>
        <br/>
        Phone Number:
        <input name="phoneNo" id="phoneNumber" type="text" value="<?php echo $rPhoneNo; ?>"/><span class="error"><?php echo $phoneError; ?></span>
		 <br/>
         <br/>
		Tick here if you are student:
        <input type="checkbox" id="studentdiscount" name="student" onChange="redraw()"/>
      <br/>
      <button type="submit" name="submit" value="Place Order" >Submit order</button>
    </form>

    <?php

?>
